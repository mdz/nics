typedef union {
  char ch;
  int num;
  ChessPiece::Type piece;
  Sclarifier clarifier;
  Ssquare square;
  Schessmove move;
} YYSTYPE;


extern YYSTYPE yylval;
