// -*- C++ -*-
#ifndef _CHESSMOVE_H
#define _CHESSMOVE_H

#include <stdlib.h>

#include "ChessGame.h"
#include "alg_parse_int.h"

class ChessMove {
  //
  // Public data types
  //
public:
  class InvalidMove: public runtime_error {
  public: InvalidMove( const string &what_arg ): runtime_error( what_arg ) {};
  };

  //
  // Constructors and destructors
  //
public:
  ChessMove() {
    start_x = start_y = end_x = end_y = en_passant_x = en_passant_y = 0;
    castling = ChessPosition::NoCastling;
    promote = ChessPiece::Empty;
  }

  ChessMove( int start_x, int start_y, int end_x, int end_y,
	     ChessPiece::Type promote = ChessPiece::Empty );

  ChessMove( ChessPosition::Castling );

  //
  // Accessors
  //
public:
  // These are guaranteed to return values in the range [1,8]
  int get_start_x() const { return start_x; };
  int get_start_y() const { return start_y; };
  int get_end_x() const   { return end_x; };
  int get_end_y() const   { return end_y; };

  // Returns the piece to promote to, for pawn moves
  ChessPiece::Type get_promote() const { return promote; };

  // Returns the type of castling done on the CURRENT move
  // (only valid if the king is being moved)
  ChessPosition::Castling get_castling() const { return castling; };

  // These will return values suitable for
  // ChessPosition::set_en_passant indicating the en passant capture
  // square AFTER this move is made
  int get_en_passant_x() const { return en_passant_x; };
  int get_en_passant_y() const { return en_passant_y; };

  //
  // Protected data
  //
protected:
  int start_x;
  int start_y;
  int end_x;
  int end_y;

  // Promoted piece, for pawn moves
  ChessPiece::Type promote;

  // Castling type, for king moves
  ChessPosition::Castling castling;

  // En passant capture square AFTER this move is made
  int en_passant_x;
  int en_passant_y;
};

#endif /* !_CHESSMOVE_H */
