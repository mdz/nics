#ifndef _PGN_LEX_H
#define _PGN_LEX_H

void init_pgn_lex( istream & );
int pgn_lex();

#endif /* !PGN_LEX_H */
