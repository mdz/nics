#include "ChessMoveCoordinateAlgebraic.h"

ChessMoveCoordinateAlgebraic::ChessMoveCoordinateAlgebraic(
							   const string &data,
							   const ChessGame &game ) {
  if ( data.length() < 3)
    throw InvalidMove("String too short to contain a valid move");
  if ( data.length() > 5 )
    throw InvalidMove("String too long to contain a valid move");

  if ( data == "o-o" ) {
    castling = ChessPosition::Kingside;
    return;
  }
  if ( data == "o-o-o" ) {
    castling = ChessPosition::Queenside;
    return;
  }

  if ( data[0] < 'a' || data[0] > 'h' )
    throw InvalidMove("Invalid file specification");

  start_x = data[0] - 'a' + 1;

  if ( data[1] < '1' || data[1] > '8' )
    throw InvalidMove("Invalid rank specification");

  start_y = data[1] - '1' + 1;

  if ( data[2] < 'a' || data[2] > 'h' )
    throw InvalidMove("Invalid file specification");

  end_x = data[2] - 'a' + 1;

  if ( data[3] < '1' || data[3] > '8' )
    throw InvalidMove("Invalid rank specification");

  end_y = data[3] - '1' + 1;

  if ( data.length() > 4 ) {
    switch ( data[4] ) {
    case 'q':
      promote = ChessPiece::Queen;break;
    case 'r':
      promote = ChessPiece::Rook;break;
    case 'n':
      promote = ChessPiece::Knight;break;
    case 'b':
      promote = ChessPiece::Bishop;break;
    default:
      throw InvalidMove("Invalid piece specification");
    }
  }
}
