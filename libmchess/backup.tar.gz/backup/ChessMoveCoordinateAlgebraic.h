// -*- C++ -*-
#ifndef _CHESSMOVECOORDINATEALGEBRAIC_H
#define _CHESSMOVECOORDINATEALGEBRAIC_H

#include <string>

#include "ChessMove.h"

class ChessGame;

class ChessMoveCoordinateAlgebraic: public ChessMove {
 public:
  ChessMoveCoordinateAlgebraic( const string &data,
				const ChessGame &game );
};

#endif /* !_CHESSMOVEALGEBRAIC_H */
