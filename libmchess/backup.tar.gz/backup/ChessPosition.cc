#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifdef HAVE_ASSERT_H
#include <assert.h>
#else
#define assert(x)
#endif

#include <cstdlib>
#include <iostream>
#include <strstream>
#include <cctype>
#include <stdexcept>

#include "ChessPosition.h"

// A FEN for the position at the start of a game
static const char *start_FEN =
"rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

ChessPosition::ChessPosition() throw (ChessPosition::InvalidPosition):
  en_passant_x(0),
  en_passant_y(0),
  halfmove_clock(0),
  fullmove_number(1),
  check(0) {
  
  set_castling( White, Kingside, 1 );
  set_castling( White, Queenside, 1 );
  set_castling( Black, Kingside, 1 );
  set_castling( Black, Queenside, 1 );

  // There ought to be a faster way to initialize to the default
  // starting position, but this is a good self-test for now
  istrstream s( start_FEN );
  read_FEN( s );
}

const ChessPiece &ChessPosition::get_piece_at( const char *square ) const {
  return get_piece_at( square_x( square ), square_y( square ) );
}

int ChessPosition::get_castling( Color color,
				 Castling castling ) const {
  assert( color == White || color == Black );
  assert( castling == Kingside || castling == Queenside );

  if (color == White)
    switch ( castling ) {
    case Kingside:
      return castling_white_kingside;
    case Queenside:
      return castling_white_queenside;
    default:
      throw invalid_argument("castling");
    }
  else
    switch ( castling ) {
    case Kingside:
      return castling_black_kingside;
    case Queenside:
      return castling_black_queenside;
    default:
      throw invalid_argument("castling");
    }
}
  
int ChessPosition::get_en_passant_x() const {
  return en_passant_x;
}

int ChessPosition::get_en_passant_y() const {
  return en_passant_y;
}

int ChessPosition::get_halfmove_clock() const {
  return halfmove_clock;
}

int ChessPosition::get_fullmove_number() const {
  return fullmove_number;
}

void ChessPosition::write_FEN( ostream &output ) const {
  int x, y;
  int empty_ctr = 0;
  int any_castling = 0;

  //
  // Piece placement data
  //
  for ( y = 7 ; y >= 0 ; --y ) {
    for ( x = 0 ; x < 8 ; ++x ) {
      if ( board[x][y].get_type() == ChessPiece::Empty ) {
	++empty_ctr;
      } else {
	if ( empty_ctr != 0) { // End of a series of empty squares
	  output << empty_ctr;
	  empty_ctr = 0;
	}

	output << board[x][y].piece_char();
      }
    }

    if ( empty_ctr != 0 ) { // Empty rank
      output << empty_ctr;
      empty_ctr = 0;
    }

    if (y > 0)
      output << '/';
  }

  output << ' '; // Field separator

  //
  // Active color
  //
  if ( active_color == White ) {
    output << 'w';
  } else if ( active_color == Black ) {
    output << 'b';
  } else { // Should never happen
    throw InvalidPosition("Unable to determine active color");
  }

  output << ' '; // Field separator

  //
  // Castling availability
  //
  if ( get_castling( White, Kingside ) ) {
    any_castling = 1;
    output << 'K';
  }

  if ( get_castling( White, Queenside ) ) {
    any_castling = 1;
    output << 'Q';
  }
  
  if ( get_castling( Black, Kingside ) ) {
    any_castling = 1;
    output << 'k';
  }

  if ( get_castling( Black, Queenside ) ) {
    any_castling = 1;
    output << 'q';
  }

  if (!any_castling) {
    output << '-';
  }

  output << ' '; // Field separator

  //
  // En passant target square
  //
  if ( en_passant_x != 0 
       && en_passant_y != 0 ) {

    output << (char)('a' + en_passant_x - 1);
    output << (char)('1' + en_passant_y - 1);

  } else {
    output << '-';
  }

  output << ' ';

  //
  // Halfmove clock
  //
  output << halfmove_clock << ' ';

  //
  // Fullmove number
  //
  output << fullmove_number << endl;
}

void ChessPosition::set_piece_at( const char *square,
				  const ChessPiece &piece ) {
  set_piece_at( square_x( square ), square_y( square ), piece );
}

void ChessPosition::set_active_color( Color color ) {
  active_color = color;
}

void ChessPosition::set_castling( ChessPosition::Color color,
				  ChessPosition::Castling castling,
				  int on ) {
  assert( color == White || color == Black );
  assert( castling == Queenside || castling == Kingside );

  if ( color == White )
    switch ( castling ) {
    case Kingside:
      castling_white_kingside = on;
      break;
    case Queenside:
      castling_white_queenside = on;
      break;
    default:
      throw invalid_argument("castling");
    }
  else
    switch ( castling ) {
    case Kingside:
      castling_black_kingside = on;
      break;
    case Queenside:
      castling_black_queenside = on;
      break;
    default:
      throw invalid_argument("castling");
    }
}

void ChessPosition::set_en_passant( int x, int y ) {
  en_passant_x = x;
  en_passant_y = y;
}

void ChessPosition::set_halfmove_clock( int value ) {
  halfmove_clock = value;
}

void ChessPosition::set_fullmove_number( int value ) {
  fullmove_number = value;
}

void ChessPosition::read_FEN( istream &input )
  throw (ChessPosition::InvalidPosition) {
  char ch;
  string str;
  int num;

  for( int y = 7 ; y >= 0 ; --y ) {
    for( int x = 0 ; x < 8 ;  ) {
      ch = input.get();

      if ( isdigit( ch ) ) {
	int count = ch -  '1' + 1;
	x += count;
	//cerr << "Skipping " << count << " squares" << endl;
      } else {
	board[x][y].set( ch );
	//cerr << "Got piece (" << *current << "): "
	//     << board[x][y].get_type() << ','
	++x;
      }
    }

    if ( y > 0 ) {
      ch = input.get();
      if ( ch != '/' ) { // Bad FEN
	throw InvalidPosition("Expected slash at end of rank in FEN");
      }

    }
  }

  if ( input.get() != ' ' ) { // Check field separator
    throw InvalidPosition("Missing field separator in FEN");
  }

  ch = input.get();
  if ( ch == 'w' ) {
    set_active_color( White );
  } else if ( ch == 'b' ) {
    set_active_color( Black );
  } else {
    throw InvalidPosition("Couldn't determine active color from FEN");
  }

  ch = input.get();
  if ( ch != ' ' ) {
    throw InvalidPosition("Missing field separator in FEN");
  }

  input >> str;

  // Castling
  if ( str.find('K') != string::npos ) {
    set_castling( White, Kingside, 1 );
  }
  if ( str.find('Q') != string::npos ) {
    set_castling( White, Queenside, 1 );
  }

  if ( str.find('k') != string::npos ) {
    set_castling( Black,  Kingside, 1 );
  }
  if ( str.find('q') != string::npos ) {
    set_castling( Black, Queenside, 1 );
  }

  // En passant square
  input >> str;
  if ( str == "-" ) {
    set_en_passant( 0, 0 );
  } else if ( str.length() == 2 ) {
    
    set_en_passant( str[0] - 'a' + 1,
		    str[1] - '1' + 1 );
  } else {
//      cerr << "ChessPosition::read_FEN: invalid en passant square" << endl;
    throw InvalidPosition("Invalid en passant square in FEN");
  }

  input >> num;

  set_halfmove_clock( num );

  input >> num;

  set_fullmove_number( num );

  test_for_check( White );
  int was_check = check;
  test_for_check( Black );

  if ( was_check == 1 && check == 1 )
    throw InvalidPosition("Both kings are in check");
}

int ChessPosition::square_x( const char *square ) {
  char file;
  assert( strlen(square) == 2 );

  file = tolower(square[0]);
  assert( file >= 'a' && file <= 'h');
  return file - 'a' + 1;
}

int ChessPosition::square_y( const char *square ) {
  char rank;
  assert( strlen(square) == 2 );

  rank = tolower(square[1]);
  assert( rank >= '1' && rank <= '8' );
  return rank - '1' + 1;
}

void ChessPosition::increment_move() {
  switch ( active_color ) {
  case White:
    active_color = Black;
    break;
  case Black:
    ++fullmove_number;
    active_color = White;
    break;
  default:
    assert(0);
  }
}

// 1. Find any piece that can move there (is_attacked)
// find_piece(end_x, end_y)
// 2. Find any piece of type X and color Y that can move there
//    without causing check (algmove)
// find_piece(piece, end_x, end_y)
// 3. Find any piece of type X and color Y that can move there from
// the specified rank and/or file without causing check (algmove)
// find_piece(piece, end_x, end_y, rank, file)
// 4. Find any piece of color X that can move anywhere without causing
//    check(mate test)
// find_piece(color)
//
// find_moves(type = anytype, color = anycolor

struct find_piece_callback_data {
  const ChessPosition *pos;
  ChessPositionCoords *found_pieces;
  ChessPiece::Color color;
  int file;
  int rank;
  int testlegal;
  int found;
};

int find_piece_callback( ChessPiece::Type type,
			 int start_x, int start_y, int end_x, int end_y,
			 void *vdata ) {
  find_piece_callback_data *data = (find_piece_callback_data *)vdata;

  if ( data->file != 0 && data->file != end_x )
    return 0;
  if ( data->rank != 0 && data->rank != end_y )
    return 0;

  cerr << "Looking for a " << type
       << " piece on (" << end_x << ',' << end_y << ')' << endl;

  ChessPiece found_piece = data->pos->get_piece_at( end_x, end_y );
  if ( found_piece.get_type() != ChessPiece::Empty
       && (data->type == ChessPiece::AnyType
	   || found_piece.get_type() == data->type ) ) {

    if ( data->found_pieces != NULL ) {
      data->found_pieces[ data->found ].x = end_x;
      data->found_pieces[ data->found ].y = end_y;
    }

    ++(data->found);

    // Stop searching this vector (we found a piece)
    return 1;

  } else if ( found_piece.get_type() != ChessPiece::Empty ) {

    // Stop searching this vector (there is a piece in the way)
    return 1;
  }

  // Continue searching
  return 0;
}

int ChessPosition::find_piece( ChessPiece::Type type, ChessPiece::Color color,
                               int end_x, int end_y,
                               int file,
                               int rank,
			       int testlegal,
			       ChessPositionCoords *found_pieces )
  const {
  find_piece_callback_data data;
  data.pos = this;
  data.color = color;
  data.found_pieces = found_pieces;
  data.file = file;
  data.rank = rank;
  data.found = 0;
  data.testlegal = testlegal;

  ChessPiece::walk_vectors( type, color,
			    end_x, end_y, -1,
			    &find_piece_callback, (void *)&data );

  return data.found;
}

void ChessPosition::test_for_check( Color color ) {
  ChessPiece::Color piece_color = ( color == White ) ?
    ChessPiece::White : ChessPiece::Black;
  ChessPiece::Color opponent_piece_color = ( piece_color == ChessPiece::White 
					     ? ChessPiece::Black
					     : ChessPiece::White );

  check = -1; // Assume no

  //
  // Find the king.  We could store its location always, but this
  // should run pretty fast.
  //
  int king_x = 0, king_y = 0;

  for( int x = 1 ; x <= 8 ; ++x ) {
    for( int y = 1 ; y <= 8 ; ++y ) {
      if ( get_piece_at( x, y ) ==
	   ChessPiece( ChessPiece::King, piece_color ) ) {

	king_x = x;
	king_y = y;

	if ( find_piece( ChessPiece::AnyType, opponent_piece_color,
			 king_x, king_y, 0, 0, 0, NULL ) ) {
	  // Check
	  check = 1;
	  check_who = color;
	  cerr << "test_for_check: " << color << " is in check" << endl;
	} else {
	  check = -1;
	}

	return;
      }
    }
  }

  // No king
  throw InvalidPosition("Missing king");
}

//  int ChessPosition::checkmate() {
//    if ( check == -1 )
//      return 0;

//    // Find all possible moves
//    // XXX - check promotion moves and maybe en passant
//    for( int x = 1 ; x <= 8 ; ++x ) {
//      for( int y = 1 ; y <= 8 ; ++y ) {
//        const ChessPieceVector *vectors;
//        unsigned int num_vectors = get_piece_at(x,y).get_vectors( vectors );

//        for( int v = 0 ; v < num_vectors ; ++v ) {
//  	for( int len = 1 ; len < vectors[v].length ; ++len ) {
//  	  int end_x = x + vectors[v].x * len;
//  	  int end_y = y + vectors[v].y * len;
//  	  ChessMove move(x, y, end_x, end_y);
//  	  ChessGame testgame(*this);
	  
//  	  try {
//  	    testgame.make_move(move);
//  	  } catch (ChessGame::IllegalMove) {
//  	    continue;
//  	  }

//  	  // There was a legal move
//  	  return 0;
//  	}
//        }
//      }
//    }

//    return 1;
//  }

int ChessPosition::in_check( Color color ) {
  if ( check == 0 ) // We didn't already know, so run a full test
    test_for_check( color );

  return ( check == 1 && check_who == color );
}
