// -*- C++ -*-
#ifndef _CHESSPIECE_H
#define _CHESSPIECE_H

struct ChessPieceVector {
  int x;
  int y;
  unsigned int length;
};

class ChessPiece {
  //
  // Public data types
  //
 public:
  enum Type { Empty, Pawn, Knight, Bishop, Rook, Queen, King, AnyType };
  enum Color { White, Black };

  //
  // Constructors and destructors
  //
 public:
  // For type = Empty, color is ignored
  ChessPiece(Type _type = Empty, Color _color = White):
    type( _type ), color( _color ) {};

  //
  // Accessors
  //
 public:
  Type get_type() const { return type; };
  Color get_color() const { return color; };
  // Return the character symbol for a piece (SAN notation)
  // lowercase p, n, b, etc. for black, uppercase for white
  char piece_char() const;

  // Set a pointer to an array of vectors for this piece, return the
  // number of vectors
  unsigned int get_vectors(const ChessPieceVector **dst) const;

  //
  // Mutators
  //
 public:
  void set_type(Type type_) { type = type_; };
  void set(char);
  void set_color(Color color_) { color = color_; };

  //
  // Operators
  //
public:
  inline friend int operator==( const ChessPiece &a, const ChessPiece &b ) {
    if ( a.type == ChessPiece::Empty && b.type == ChessPiece::Empty )
      return 1;
    
    return ( a.type == b.type && a.color == b.color );
  }

  static void walk_vectors( Type type, Color color,
			    int start_x,
			    int start_y,
			    int direction,
			    int (*callback)
			    (Type type,
			     int start_x, int start_y,
			     int end_x, int end_y,
			     void *data),
			    void *data );

  //
  // Private data
  //
 private:
  Type type;
  Color color;
};

#endif /* !_CHESSPIECE_H */
