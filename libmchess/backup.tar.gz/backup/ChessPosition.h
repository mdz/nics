// -*- C++ -*-
#ifndef _CHESSPOSITION_H
#define _CHESSPOSITION_H

#include "ChessPiece.h"
#include <string>
#include <assert.h>
#include <stdexcept>

struct ChessPositionCoords {
  int x;
  int y;
};

//
// Note: all positions are specified in rank-file notation (e.g., a4,
// h7, etc.), except in the (x, y) forms of certain functions, (which
// accept numerical coordinates in the range [1,8]
//

class ChessPosition {
  //
  // Public data types
  //
public:
  enum Color { White, Black, AnyColor };
  enum Castling { NoCastling, Queenside, Kingside, AnyCastling };

  class InvalidPosition: public runtime_error {
  public:
    InvalidPosition( const string &what_arg ):
      runtime_error( what_arg ) {};
  };

  //
  // Constructors and destructors
  //
public:

  // Default constructor
  // (start-of-game position)
  ChessPosition() throw (InvalidPosition);

  // FEN constructor
  ChessPosition( const string &fen ) throw (InvalidPosition);

  //
  // Accessors
  //
public:
  // What sort of piece is at position (x, y)
  // x and y have the range [1,8]
  inline const ChessPiece &get_piece_at( int x, int y ) const {
    assert( x >= 1 && x <= 8);
    assert( y >= 1 && y <= 8);
    return board[x - 1][y - 1];
  }

  // What piece is at <square>?
  const ChessPiece &get_piece_at( const char *square ) const;

  // Whose turn is it?
  Color get_active_color() const { return active_color; };

  // Can the specified player castle in the specified manner?
  int get_castling( Color, Castling ) const;

  // If an en passant capture is possible, on which square?
  // If none, returns 0
  int get_en_passant_x() const;
  int get_en_passant_y() const;

  // How many half-moves since the last pawn advance or capturing move?
  int get_halfmove_clock() const;

  // How many full moves so far in the game?
  int get_fullmove_number() const;

  // Write position data as a FEN to a stream
  void write_FEN( ostream &output ) const;

  // In the specified square being attacked by the specified color?
  int is_attacked( const char *square, Color ) const;
  int is_attacked( int x, int y, Color ) const;

  // Is the specified color king in check?  Can't be const, as it
  // caches the result
  int in_check( Color color );

  int checkmate();

  // Find pieces equal to piece that are capable of moving to (end_x,
  // end_y) The search can be restricted to a specified rank or
  // file. On success, the coordinates of the pieces are stored in the
  // array pointed to by found_pieces, and the number of pieces found
  // is returned
  int find_piece( ChessPiece::Type type, ChessPiece::Color color,
		  int end_x, int end_y,
		  int rank,
		  int file,
		  int testlegal,
		  ChessPositionCoords *found_pieces ) const;

  //
  // Mutators
  //
public:
  // Place a piece at position (x, y)
  // (replacing any existing piece on that square)
  // x and y have the range [1,8]
  void set_piece_at( int x, int y, const ChessPiece &piece ) {
    assert(x >= 1 && x <= 8);
    assert(y >= 1 && y <= 8);
    board[x - 1][y - 1] = piece;
    check = 0; // Invalidate known check state
  }


  // Place a piece at <square>
  // (replacing any existing piece on that square)
  void set_piece_at( const char *square, const ChessPiece &piece );

  // Set active color
  void set_active_color( Color );

  // Set castling availability (on=1 to enable, on=0 to disable)
  void set_castling( Color, Castling, int on );

  // Set en passant move (0, 0 for none)
  void set_en_passant( int x, int y );

  // Set the halfmove clock
  void set_halfmove_clock( int );

  // Set the fullmove number
  void set_fullmove_number( int );

  // Increment the halfmove clock, and (if appropriate) the fullmove
  // number
  void increment_move();

  // Read a FEN from an in-memory buffer Returns 1 if successful, 0 if
  // the buffer does not contain a valid FEN
  void read_FEN( istream &input ) throw (InvalidPosition);

  //
  // Protected member functions
  //
protected:
  // Convert between SAN square notation and integer coordinates
  static int square_x( const char *square);
  static int square_y( const char *square);
  static const char *make_square( int x, int y );

private:
  void test_for_check( Color color );

  //
  // Private data
  //
private:
  ChessPiece board[8][8];
  Color active_color;
  int castling_white_kingside;
  int castling_white_queenside;
  int castling_black_kingside;
  int castling_black_queenside;
  int en_passant_x;
  int en_passant_y;
  int halfmove_clock;
  int fullmove_number;
  int check; // Is someone in check? -1 => no, 0 => don't know, 1 => yes
  Color check_who; // If yes, whom?
};

#endif /* !_CHESSPOSITION_H */
