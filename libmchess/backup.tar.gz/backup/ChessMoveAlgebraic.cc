#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "ChessMoveAlgebraic.h"

ChessMoveAlgebraic::ChessMoveAlgebraic( const string &data,
					const ChessPosition &pos )
  throw (ChessMove::InvalidMove) {

  ChessPosition::Color pos_color = pos.get_active_color();
  ChessPiece::Color piece_color = pos_color == ChessPosition::White ?
    ChessPiece::White : ChessPiece::Black;

  // Inexpensive sanity check before calling the parser
  if ( data.length() < 2 )
    throw InvalidMove("String too short to be an algebraic move");
  
  //
  // Call the algebraic notation parser
  //
  
  Schessmove *move = do_alg_parse( data.c_str() );
  
  if (!move)
    throw InvalidMove("Parse error");

#ifdef DEBUG_ChessMove
    cerr << "Parsed move:" << endl
	 << "piece: " << (int)move->piece << endl
	 << "clarifier.rank: " << move->clarifier.rank << endl
	 << "clarifier.file: " << move->clarifier.file << endl
	 << "square.rank: " << move->square.rank << endl
	 << "square.file: " << move->square.file << endl
	 << "capture: " << move->capture << endl
	 << "check: " << move->check << endl
	 << "promote: " << (int)move->promote << endl
	 << "castling: " << (int)move->castling << endl
	 << endl;
#endif
  
  ChessPiece piece( move->piece, piece_color );
  
  // Make sure we got a valid piece
  
  switch ( piece.get_type() ) {
  case ChessPiece::Pawn:
  case ChessPiece::Bishop:
  case ChessPiece::Knight:
  case ChessPiece::Rook:
  case ChessPiece::Queen:
  case ChessPiece::King:
    break;
  default:
    throw InvalidMove("Unable to determine piece type");
  }

    
  //
  // Sanity checks...trust no one...not even the parser.
  //

  if ( move->castling != ChessPosition::NoCastling
       && ( move->castling == ChessPosition::Kingside
	    || move->castling == ChessPosition::Queenside ) )

    castling = move->castling;

  if ( castling == ChessPosition::NoCastling ) {

    if ( move->square.file >= 1 && move->square.file <= 8 )
      end_x = move->square.file;
    else
      throw InvalidMove("Move coordinate out of range");

    if (  move->square.rank >= 1 && move->square.rank <= 8 )
      end_y = move->square.rank;
    else 
      throw InvalidMove("Move coordinate out of range");

  }

  // Check the clarifier...a problem here would be indicative of a
  // programmatic error in the parser
  assert( !( move->clarifier.rank && move->clarifier.file ) );

  // Check active color
  assert( pos_color == ChessPosition::White
	  || pos_color == ChessPosition::Black );

  // Make sure we're not trying to capture our own piece, or make a
  // null move

  if ( castling == ChessPosition::NoCastling ) {
    ChessPiece end_piece = pos.get_piece_at( end_x, end_y );

    if ( end_piece.get_type() != ChessPiece::Empty &&
	 end_piece.get_color() == piece_color )
      throw InvalidMove("Attempt to move onto a piece of the same color");

    if ( start_x == end_x && start_y == end_y )
      throw InvalidMove("Attempt to move a piece onto the square it already occupies");
  }

  if ( castling == ChessPosition::NoCastling ) {
    //
    // Determine start square
    //
    
    int found = 0;
    ChessPositionCoords found_pieces[8];
    switch ( piece.get_type() ) {
      //
      // Pawn moves
      //
    case ChessPiece::Pawn:
      int dir, eighth_rank, second_rank;
      
      if ( pos_color == ChessPosition::White ) {
	dir = 1;
	second_rank = 2;
      } else {
	dir = -1;
	second_rank = 7;
      }

      eighth_rank = second_rank + ( 6 * dir );

      if ( end_y == ( second_rank ) || end_y == (second_rank - dir) )
	throw InvalidMove("Attempt to move pawn onto player's first or second rank");

      if ( move->capture ) {
	//
	// Pawn captures
	//

	start_x = move->clarifier.file;
	start_y = end_y - dir;

	if ( !( start_x >= 1 && start_x <= 8 ) ) {
	  throw InvalidMove("Move coordinate out of range");
	}

      } else {
	//
	// Pawn moves without capture
	//

	start_x = end_x;
	
	if ( ( end_y == second_rank + ( dir * 2 ) )
	     && ( pos.get_piece_at( end_x, second_rank + dir )
		  .get_type() == ChessPiece::Empty )
	     && ( pos.get_piece_at( end_x, second_rank )
		  == ChessPiece( ChessPiece::Pawn, piece_color ) ) ) {
	  //
	  // Initial two-square advance
	  //

	  start_y = second_rank;
	  en_passant_x = start_x;
	  en_passant_y = second_rank + dir;

	} else if ( pos.get_piece_at( end_x, end_y - dir )
		    == ChessPiece( ChessPiece::Pawn, piece_color )
		    && pos.get_piece_at( end_x, end_y ).get_type() 
		    == ChessPiece::Empty ) {
	  //
	  // Normal pawn move
	  //

	  start_y = end_y - dir;

	} else {
	  throw InvalidMove("Invalid pawn move");
	}
      }
      
      if ( pos.get_piece_at( start_x, start_y ).get_type()
	   != ChessPiece::Pawn ) {
	throw InvalidMove("Invalid pawn move");
      }

      if ( end_y == eighth_rank )
	if ( move->promote == ChessPiece::Empty )
	  throw InvalidMove("Pawn move onto eighth rank without promotion");
	else
	  promote = move->promote;

      break;

    case ChessPiece::Knight:
    case ChessPiece::Bishop:
    case ChessPiece::Rook:
    case ChessPiece::Queen:
    case ChessPiece::King:
      found = pos.find_piece( piece.get_type(), piece.get_color(),
			      end_x,
			      end_y,
			      move->clarifier.file,
			      move->clarifier.rank,
			      1,
			      found_pieces );
    
      if ( !found )
	throw InvalidMove("No piece found capable of moving onto destination square");
    
      else if ( found > 1 ) {
	find_legal_move( found, found_pieces, pos );
      } else {
      
	// We found exactly one matching piece
	start_x = found_pieces[0].x;
	start_y = found_pieces[0].y;
      }
    
      break;

    default:
      // Should never happen, since we checked this case above
      assert(0);
    }
  }
    
  //      cerr << "start_x: " << start_x << endl;
  //      cerr << "start_y: " << start_y << endl;
}


string ChessMoveAlgebraic::text() const {
  return string("");
}

void ChessMoveAlgebraic::find_legal_move( int num_pieces,
					  ChessPositionCoords *pieces,
					  const ChessPosition &pos ) {
  int legal = -1;
  for( int i = 0 ; i < num_pieces ; ++i ) {

    ChessPosition try_it( pos );
    int x = pieces[i].x, y = pieces[i].y;

    try_it.set_piece_at( end_x, end_y,
			 try_it.get_piece_at( x, y ) );
    try_it.set_piece_at( x, y, ChessPiece( ChessPiece::Empty ) );

    if ( !try_it.in_check( try_it.get_active_color() ) ) {

      if ( legal >= 0 ) // More than one legal move
	throw InvalidMove("Algebraic move is ambiguous");

      legal = i;
    }
  }

  if ( legal >= 0 ) {
    // Exactly one legal move

    start_x = pieces[legal].x;
    start_y = pieces[legal].y;

  } else {
    // No legal moves

    throw InvalidMove("No piece able to legally execute move (pin?)");
  }
}
