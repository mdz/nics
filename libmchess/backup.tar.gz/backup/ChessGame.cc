#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifdef HAVE_ASSERT_H
#include <assert.h>
#else
#define assert(x)
#endif

#include <iostream>

#include "pgn_parse_int.h"
#include "ChessGame.h"

ChessGame::ChessGame() {
  int i;
  for( i = 0 ; i < CHESSGAME_MAX_MOVES ; ++i ) {
    moves[i] = NULL;
  }
}

ChessGame::ChessGame( istream &input ) {
  ChessGame();
  if (do_pgn_parse( input, this ) != 0)
    throw;
}

ChessGame::ChessGame( const ChessPosition &pos ):
  position(pos) {
  ChessGame();
}

void ChessGame::make_move( const ChessMove &move ) {
  ChessPosition::Color active_color = position.get_active_color()
;
  ChessPosition old_position(position);

  if ( move.get_castling() != ChessPosition::NoCastling ) {
    int old_king_file = 5, new_king_file;
    int old_rook_file, new_rook_file;
    int back_rank;

    if ( active_color == ChessPosition::White )
      back_rank = 1;
    else
      back_rank = 8;

    // Are we allowed to castle?
    if ( !position.get_castling( active_color, move.get_castling() ) )
      throw IllegalMove("Attempt to castle when castling has been disallowed");

    if ( position.in_check( active_color ) )
      throw IllegalMove("Attempt to castle when in check");

    // XXX - variants
    switch ( move.get_castling() ) {
    case ChessPosition::Kingside:
      new_king_file = 7;
      old_rook_file = 8;
      new_rook_file = 6;
      break;
    case ChessPosition::Queenside:
      new_king_file = 3;
      old_rook_file = 1;
      new_rook_file = 4;
      break;
    default:
      // ChessMove will not allow this
      assert( 0 );
    }

    // XXX - check castling through check

    // Move king
    position.set_piece_at( new_king_file, back_rank,
			   position.get_piece_at( old_king_file, back_rank ) );
    position.set_piece_at( old_king_file, back_rank,
			   ChessPiece( ChessPiece::Empty ) );

    // Move rook
    position.set_piece_at( new_rook_file, back_rank,
			   position.get_piece_at( old_rook_file, back_rank ) );
    position.set_piece_at( old_rook_file, back_rank,
			   ChessPiece( ChessPiece::Empty ) );

    // No more castling
    position.set_castling( active_color, ChessPosition::Kingside, 0 );
    position.set_castling( active_color, ChessPosition::Queenside, 0 );
  } else {
    // Handle normal moves
    int start_x = move.get_start_x();
    int start_y = move.get_start_y();
    int end_x = move.get_end_x();
    int end_y = move.get_end_y();
    ChessPiece captured_piece( position.get_piece_at( end_x, end_y ) );
    ChessPiece moved_piece( position.get_piece_at( start_x,
						 start_y ) );

    assert( moved_piece.get_type() != ChessPiece::Empty );

#ifdef DEBUG_ChessGame
    cerr << "Making move: " << endl
	 << "start_x: " << start_x << endl
	 << "start_y: " << start_y << endl
	 << "end_x: " << end_x << endl
	 << "end_y: " << end_y << endl;
#endif

    if ( moved_piece.get_type() == ChessPiece::Pawn ) {
      int second_rank = active_color == ChessPosition::White ? 2 : 7;
      if ( start_x == end_x && captured_piece.get_type() != ChessPiece::Empty )
	throw IllegalMove("Pawn attempted to march over another piece");

      if ( ( (end_y - start_y) == 2 || (end_y - start_y) == -2 )
	   && start_y != second_rank )
	throw IllegalMove("Pawn attempted to advance two squares when not on second rank");
    }

    position.set_piece_at( start_x,
			   start_y,
			   ChessPiece( ChessPiece::Empty ) );
    position.set_piece_at( end_x,
			   end_y,
			   moved_piece );
    
    // Handle en passant captures (capture the pawn)
    if ( moved_piece.get_type() == ChessPiece::Pawn
	 && end_x == position.get_en_passant_x()
	 && end_y == position.get_en_passant_y() ) {
      int dir = (position.get_active_color()
		 == ChessPosition::White) ? 1 : -1;
      position.set_piece_at( end_x, end_y - dir,
			     ChessPiece( ChessPiece::Empty ) );
    }

    // No more castling if we move the king
    if ( moved_piece.get_type() == ChessPiece::King ) {
      position.set_castling( active_color, ChessPosition::Kingside, 0 );
      position.set_castling( active_color, ChessPosition::Queenside, 0 );
    }

    // No more castling if anything moves onto or off of the rook squares
    // XXX - variants
    if ( start_y == 1 && start_x == 8
	 || end_y == 1 && end_x == 8 )
      position.set_castling( ChessPosition::White,
			     ChessPosition::Kingside, 0 );
    if ( start_y == 1 && start_x == 1
	 || end_y == 1 && end_x == 1 )
      position.set_castling( ChessPosition::White,
			     ChessPosition::Queenside, 0 );

    if ( start_y == 8 && start_x == 8
	 || end_y == 8 && end_x == 8 )
      position.set_castling( ChessPosition::Black,
			     ChessPosition::Kingside, 0 );

    if (start_y == 8 && start_x == 1
	|| end_y == 8 && end_x == 1 )
      position.set_castling( ChessPosition::Black,
			     ChessPosition::Queenside, 0 );
    
    // Handle pawn promotion (change the recently placed pawn into
    // another piece)
    if ( moved_piece.get_type() == ChessPiece::Pawn
	 && move.get_promote() != ChessPiece::Empty )
      position.set_piece_at( end_x, end_y,
			     ChessPiece( move.get_promote(),
					 moved_piece.get_color() ) );
    
    
    // Set new en passant info
    position.set_en_passant( move.get_en_passant_x(),
			     move.get_en_passant_y() );
    
    // Set halfmove clock
    if ( captured_piece.get_type() != ChessPiece::Empty ||
	 moved_piece.get_type() == ChessPiece::Pawn ) 
      position.set_halfmove_clock( 0 );
    else
      position.set_halfmove_clock( position.get_halfmove_clock() + 1 );
  
  }
  
  // Check if the player who just moved is in check
  if (position.in_check(active_color) ) {
    position = old_position;
    throw IllegalMove("Move puts player in check");
  }
  
  // Increment fullmove clock if appropriate
  position.increment_move();

#ifdef DEBUG_ChessGame
  cerr << "Position after move: ";
  position.write_FEN( cerr );
#endif
}

void ChessGame::pgn_tag( const string &name, const string &value ) {
  if ( name == "Event" ) {
    event(value);
  } else if ( name == "Site" ) {
    site(value);
  } else if ( name == "Date" ) {
    date(value);
  } else if ( name == "Round" ) {
    round(value);
  } else if ( name == "White" ) {
    white(value);
  } else if ( name == "Black" ) {
    black(value);
  } else if ( name == "Result" ) {
    result(value);
  }

  // Throw away unknown tags
}
