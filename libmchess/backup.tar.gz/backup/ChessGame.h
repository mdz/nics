// -*- C++ -*-
#ifndef _CHESSGAME_H
#define _CHESSGAME_H

#include "ChessPosition.h"
#include "ChessMove.h"
#include <iostream>
#include <string>

#define CHESSGAME_MAX_MOVES 200

class ChessGame {
  //
  // Constructors and destructors
  //
public:
  // Default constructor (initial game setup, move 1)
  ChessGame();

  // Read PGN data
  ChessGame( istream &input );

  // Start from a position
  ChessGame( const ChessPosition & );

  enum Winner { WhiteWins, BlackWins, Draw, AnyWinner };
  enum Ending { Checkmate, Stalemate, Flag };

  //
  // Exceptions
  //
  class PGNParseError: public runtime_error {
  public: PGNParseError( const string &what_arg ): runtime_error( what_arg ) {};
  };

  class PGNEmpty: public underflow_error {
  public: PGNEmpty( const string &what_arg ): underflow_error( what_arg ) {};
  };

  class IllegalMove: public runtime_error {
  public: IllegalMove( const string &what_arg ): runtime_error( what_arg ) {};
  };

  //
  // Accessors
  //
  const ChessPosition &current_position() const { return position; };

  const string &event() const { return tags.event; };
  const string &site() const { return tags.site; };
  const string &date() const { return tags.date; };
  const string &round() const { return tags.round; };
  const string &white() const { return tags.white; };
  const string &black() const { return tags.black; };
  const string &result() const { return tags.result; };
  

  //
  // Mutators
  //
  void make_move( const class ChessMove & );

  void event( const string &value ) { tags.event = value; };
  void site( const string &value ) { tags.site = value; };
  void date( const string &value ) { tags.date = value; };
  void round( const string &value ) { tags.round = value; };
  void white( const string &value ) { tags.white = value; };
  void black( const string &value ) { tags.black = value; };
  void result( const string &value ) { tags.result = value; };

  void pgn_tag( const string &name, const string &value );

  //
  // Protected data
  //
protected:
  ChessPosition position;
  class ChessMove *moves[ CHESSGAME_MAX_MOVES ];

  struct {
    string event;
    string site;
    string date;
    string round;
    string white;
    string black;
    string result;
  } tags;
};

#endif /* !_CHESSGAME_H */
