#include <assert.h>

#include <cctype>
#include <iostream>
#include <stdexcept>

#include "ChessPiece.h"

char ChessPiece::piece_char() const {
  char ret;

  switch ( type ) {
  case Empty:
    return ' ';
  case Pawn:
    ret = 'P';break;
  case Knight:
    ret = 'N';break;
  case Bishop:
    ret = 'B';break;
  case Rook:
    ret = 'R';break;
  case Queen:
    ret = 'Q';break;
  case King:
    ret = 'K';break;
  default:
    // Should never happen
    return 'X';
  }

  if ( color == Black )
    ret = tolower(ret);

  return ret;
}

void ChessPiece::set(char c) {
  switch ( toupper(c) ) {
  case 'P':
    set_type( Pawn );break;
  case 'N':
    set_type( Knight );break;
  case 'B':
    set_type( Bishop );break;
  case 'R':
    set_type( Rook );break;
  case 'Q':
    set_type( Queen );break;
  case 'K':
    set_type( King );break;
  default:
    set_type( Empty );
  }

  if ( c == tolower(c) )
    set_color( Black );
  else
    set_color( White );
}
  
unsigned int ChessPiece::get_vectors(const ChessPieceVector **dst) const {
  unsigned int size = 0;


  return size / sizeof(ChessPieceVector);
}


static int do_vector(ChessPiece piece,
		     int start_x, int start_y, int direction,
		     int vector_x, int vector_y, int vector_len,
		     int (*callback)
		     (ChessPiece piece,
		      int start_x, int start_y,
		      int end_x, int end_y,
		      void *data),
		     void *data ) {
  int x, y, len;
  for ( // Start off one square in the right direction
       x = start_x + vector_x * direction,   
	 y = start_y + vector_y * direction,
	 len = 1 ;
       
       // Stay on the board and within the magnitude of the vector
       x >= 1 && x <= 8 && y >= 1 && y <= 8
	 && len <= vector_len;
       
       // Move in the appropriate direction along the vector
       x += vector_x * direction,
	 y += vector_y * direction,
	 ++len ) {
    
    int ret = callback( piece, start_x, start_y, x, y, data );
    if ( ret == 0 ) // Continue searching
      continue;
    if ( ret == 1 ) // Stop searching this vector
      break;
    else if ( ret == 2 ) // Stop searching entirely
      return 0;
    else
      throw invalid_argument("odd value returned from callback");
  }

  return 1;
}

void ChessPiece::walk_vectors( ChessPiece::Type type,
			       ChessPiece::Color color,
			       int start_x,
			       int start_y,
			       int direction,
			       int (*callback)
			       (ChessPiece::Type type,
				int start_x, int start_y,
				int end_x, int end_y,
				void *data),
			       void *data ) {

  if ( direction < 0 )
    direction = -1;
  else if ( direction > 0 )
    direction = 1;
  else
    throw invalid_argument("direction must be nonzero");

#define DO_VECTOR(x, y, len) \
    if (!do_vector( piece, start_x, start_y, direction, \
		    x, y, len, callback, data )) \
      return

  // TODO: It should be possible to do some statistical ordering to
  // speed this up
  if ( type == AnyType || type == King ) {
    ChessPiece piece( ChessPiece::King, color );
    DO_VECTOR( 0, 1, 1 );
    DO_VECTOR( 0,-1, 1 );
    DO_VECTOR( 1, 0, 1 );
    DO_VECTOR(-1, 0, 1 );
    DO_VECTOR( 1, 1, 1 );
    DO_VECTOR(-1, 1, 1 );
    DO_VECTOR( 1,-1, 1 );
    DO_VECTOR(-1,-1, 1 );
  }
  if ( type == AnyType || type == Queen || type == Rook ) {
    DO_VECTOR( 1, 0, 8 );
    DO_VECTOR(-1, 0, 8 );
    DO_VECTOR( 0, 1, 8 );
    DO_VECTOR( 0, -1, 8 );
  }
  if ( type == AnyType || type == Queen || type == Bishop ) {
    DO_VECTOR( 1, 1, 8 );
    DO_VECTOR(-1, 1, 8 );
    DO_VECTOR( 1,-1, 8 );
    DO_VECTOR(-1,-1, 8 );
  }
  if ( type == AnyType || type == Knight ) {
    DO_VECTOR( 1, 2, 1 );
    DO_VECTOR(-1, 2, 1 );
    DO_VECTOR( 1,-2, 1 );
    DO_VECTOR(-1,-2, 1 );
    DO_VECTOR( 2, 1, 1 );
    DO_VECTOR(-2, 1, 1 );
    DO_VECTOR( 2,-1, 1 );
    DO_VECTOR(-2,-1, 1 );
  }
  if ( color == White && (type == AnyType || type == Pawn) ) {
    //    DO_VECTOR( 0, 1, 1 );
    //    DO_VECTOR( 0, 2, 1 );
    DO_VECTOR( 1, 1, 1 );
    DO_VECTOR(-1, 1, 1 );
  }
  if ( color == Black && (type == AnyType || type == Pawn) ) {
    //    DO_VECTOR( 0,-1, 1 );
    //    DO_VECTOR( 0,-2, 1 );
    DO_VECTOR( 1,-1, 1 );
    DO_VECTOR(-1,-1, 1 );
  }
}
