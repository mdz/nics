// -*- C++ -*-
#ifndef _CHESSMOVEALGEBRAIC_H
#define _CHESSMOVEALGEBRAIC_H

#include <string>

#include "ChessMove.h"

class ChessGame;

class ChessMoveAlgebraic: public ChessMove {
 public:
  ChessMoveAlgebraic( const string &data, const ChessPosition &pos )
    throw (InvalidMove);

  ChessMoveAlgebraic( const ChessMove &move, const ChessPosition &pos );

  string text() const;

 private:
  // Try to move each of the pieces at the specified coordinates to
  // the current destination square.  If exactly one is capable of
  // moving there (without resulting in check), set start_x and
  // start_y.  If zero or >1 could move there, throw InvalidMove
  void find_legal_move( int num_pieces, ChessPositionCoords *pieces,
			const ChessPosition &pos );
};

#endif /* !_CHESSMOVEALGEBRAIC_H */
