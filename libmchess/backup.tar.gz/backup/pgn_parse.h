typedef union {
  int num;
  ChessMove *move;
  string *str;
} YYSTYPE;
#define	NUM	257
#define	MOVE	258
#define	SYMBOL	259
#define	STR	260
#define	RESULT	261


extern YYSTYPE yylval;
