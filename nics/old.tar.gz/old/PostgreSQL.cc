#include "PostgreSQL.h"
#include <libpq++.h>

PostgreSQL::PostgreSQL(const char *connect):
  database(connect) {
  if (database.ConnectionBad()) {
    cerr << "Database connection failed: " << database.ErrorMessage() << endl;
    throw 0;
  }
}

void PostgreSQL::get_user(const string &name, User &user) {
  string query;

  query = "SELECT * FROM users WHERE name = '" + name + "'";
  if (!database.Exec(query.c_str())) {

    cerr << "Query failed: " << database.ErrorMessage() << endl;

  } else if (database.Tuples() > 0) {

    string n = (const char *)database.GetValue(0, database.FieldNum("name"));
    string p = (const char *)database.GetValue(0, database.FieldNum("password"));

    if (n == name) {
      user.name(n);
      user.password(p);
      return;
    }
  }

  user = User();
}

void PostgreSQL::add_user(const User &user) {
  string query = "INSERT INTO users (uid, name, password) ";
  query += "VALUES (NEXTVAL('uid'), '" + user.name()
    + "', '" + user.password() + "')";

  if (!database.Exec(query.c_str())) {
    cerr << "INSERT failed: " << database.ErrorMessage() << endl;
  }
}
