// -*- C++ -*-
#ifndef _POSTGRESQL_H
#define _POSTGRESQL_H

#include <string>
#include "NICSDatabase.h"
#include <libpq++.h>

class PostgreSQL: public NICSDatabase {
 public:
  PostgreSQL(const char *connect);
  void get_user(const string &name, User &user);
  void add_user(const User &user);

 private:
  PgDatabase database;
};

#endif // !_POSTGRESQL_H
